
public class tuple {

	Board board;
	int x;
	int y;

	public tuple(Board b, int x, int y) {
		this.board = b;
		this.x = x;
		this.y = y;
	}
}